/*
  But :    Contrôleur de matchs
  Auteur : Nathan França
  Date :   13.06.2023 / V1.0
*/
Class MatchsCtrl{
  constructor(){

  }
    var apiKey = 'ea69b94c57a14eb0bdaa9b7b872139a4';
    var elementSelectionneLeague = document.getElementById("idLeague");
    var competitionId = null;

    for(var i = 0; i < elementSelectionneLeague.options.length; i++){
        if(elementSelectionneLeague.options[i].selected){
            competitionId = elementSelectionneLeague.options[i].id;
            break;
        }
    }
    function populateTable(matches) {
      var tableBody = $('#results-table tbody');
      tableBody.empty();

      $.each(matches, function(index, match) {
        var row = $('<tr>');
        var dateCell = $('<td>').text(match.utcDate);
        var matchCell = $('<td>').text(match.homeTeam.name + ' vs ' + match.awayTeam.name);
        var resultCell = $('<td>').text(match.score.fullTime.homeTeam + ' - ' + match.score.fullTime.awayTeam);

        row.append(dateCell, matchCell, resultCell);
        tableBody.append(row);
      });
    }

    // Appeler la fonction pour récupérer les résultats du championnat depuis l'API
    getMatchs(competitionId, apiKey);
}
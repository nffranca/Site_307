/*
  But :    Contrôleur de tables
  Auteur : Nathan França
  Date :   12.06.2023 / V1.0
*/
Class TablesCtrl(){
  constructor(){

  }
    var elementSelectionneLeague = document.getElementById("idLeague");
    var optionSelectionneLeague = null;

    for(var i = 0; i < elementSelectionneLeague.options.length; i++){
        if(elementSelectionneLeague.options[i].selected){
            optionSelectionneLeague = elementSelectionneLeague.options[i].id;
            break;
        }
    }

    var elementSelectionneSaison = document.getElementById("idSeason");
    var optionSelectionneSaison = null;

    for(var i = 0; i < elementSelectionneSaison.options.length; i++){
        if(elementSelectionneSaison.options[i].selected){
            optionSelectionneSaison = elementSelectionneSaison.options[i].id;
            break;
        }
    }
// Fonction pour remplir le tableau avec les données
function populateTable(data) {
  var tableBody = $('#data-table tbody');
  tableBody.empty();

  $.each(data, function(index, item) {
    var row = $('<tr>');
    var idCell = $('<td>').text(item.id);
    var nameCell = $('<td>').text(item.name);
    var descriptionCell = $('<td>').text(item.description);

    row.append(idCell, nameCell, descriptionCell);
    tableBody.append(row);
  });
}
getTable(optionSelectionneLeague, optionSelectionneSaison);
}
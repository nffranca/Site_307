/*
 * Couche de services HTTP (worker). Comme un objet Java,
 * mais créé avec une "closure" exécutée immédiatement (IIFE).
 * Permet de rendre privées ou publiques certaines fonctions.
 *
 * @author Jean-Claude Stritt / modif P-A Mettraux
 */

/*
  But :    Services
  Auteur : França Nathan
  Date :   02.10.2023 / V2.0
*/

var apiKey = 'ea69b94c57a14eb0bdaa9b7b872139a4';
class HttpServ {
  constructor() {
  }
  centraliserErreurHttp(httpErrorCallbackFn) {
    $.ajaxSetup({
      error: function (xhr, exception) {
        let msg;
        if (xhr.status === 0) {
          msg = "Pas d'accès à la ressource serveur demandée !";
        } else if (xhr.status === 404) {
          msg = "Page demandée non trouvée [404] !";
        } else if (xhr.status === 500) {
          msg = "Erreur interne sur le serveur [500] !";
        } else if (exception === "parsererror") {
          msg = "Erreur de parcours dans le JSON !";
        } else if (exception === "timeout") {
          msg = "Erreur de délai dépassé [Time out] !";
        } else if (exception === "abort") {
          msg = "Requête Ajax stoppée !";
        } else {
          msg = "Erreur inconnue : \n" + xhr.responseText;
        }
        httpErrorCallbackFn(msg);
      },
    });
  }

  getMatchs(competitionId, season, successCallback) {
    // envoi de la requête
    $.ajax({
      url: 'https://api.football-data.org/v4/competitions/' + competitionId + '/matches?season=' + season,
      headers: { 'X-Auth-Token': apiKey },
      dataType: 'json',
      success: successCallback,
      error: function(error) {
        console.error(error);
      }
    });
  }

  getStandings(competitionId, season, successCallback) {
    // envoi de la requête
    $.ajax({
      url: 'https://api.football-data.org/v4/competitions/' + competitionId + '/standings?season=' + season,
      headers: { 'X-Auth-Token': apiKey },
      dataType: 'json',
      success: successCallback,
      error: function(error) {
        console.error(error);
      }
    });
  }
}

/*
  But :    Contrôleur 
  Auteur : França Nathan
  Date :   02.10.2023 / V2.0
*/
$().ready(function () {
  ctrl = new Ctrl();
  ctrl.matchs();
  ctrl.championnats();
});

class Ctrl {
  constructor() {
    this.httpServ = new HttpServ();
    this.httpServ.centraliserErreurHttp(this.afficherErreurHttp);
  }

  afficherErreurHttp(msg) {
    alert(msg);
  }

  matchs() {
    console.log("TEST");
    var elementSelectionneLeague = document.getElementById("idLeague");
    var competitionId = null;
    for (var i = 0; i < elementSelectionneLeague.options.length; i++) {
      if (elementSelectionneLeague.options[i].selected) {
        competitionId = elementSelectionneLeague.options[i].id;
        break;
      }
    }

    var elementSelectionneSaison = document.getElementById("idSeason");
    var optionSelectionneSaison = null;

    for (var i = 0; i < elementSelectionneSaison.options.length; i++) {
      if (elementSelectionneSaison.options[i].selected) {
        optionSelectionneSaison = elementSelectionneSaison.options[i].id;
        break;
      }
    }
    console.log("j'suis dans Match()");
    this.httpServ.getMatchs(
      competitionId,
      optionSelectionneSaison,
      this.populateTable
    );
  }

  populateTable(matches) {
    console.log(matches);
    var tableBody = $("#results-table tbody");
    tableBody.empty();

    $.each(matches.matches, function (index, match) {
      console.log(match);
      var row = $("<tr>");
      var dateCell = $("<td>").text(
        match.utcDate.replace("T", " ").replace("Z", " ")
      );
      var matchCell = $("<td>").text(
        match.homeTeam.name + " vs " + match.awayTeam.name
      );
      var resultCell = $("<td>").text(
        match.score.fullTime.home + " - " + match.score.fullTime.away
      );

      row.append(dateCell, matchCell, resultCell);
      tableBody.append(row);
    });
  }

  championnats() {
    var elementSelectionneLeague = document.getElementById("idLeague");
    var competitionId = null;
    for (var i = 0; i < elementSelectionneLeague.options.length; i++) {
      if (elementSelectionneLeague.options[i].selected) {
        competitionId = elementSelectionneLeague.options[i].id;
        break;
      }
    }

    var elementSelectionneSaison = document.getElementById("idSeason");
    var optionSelectionneSaison = null;

    for (var i = 0; i < elementSelectionneSaison.options.length; i++) {
      if (elementSelectionneSaison.options[i].selected) {
        optionSelectionneSaison = elementSelectionneSaison.options[i].id;
        break;
      }
    }
    console.log("j'suis dans Championnats()");
    this.httpServ.getStandings(
      competitionId,
      optionSelectionneSaison,
      this.populateTableStandings
    );
  }

  populateTableStandings(standings) {
    console.log(standings);
    var tableBody = $("#results-table2 tbody");
    tableBody.empty();

    $.each(standings.standings[0].table, function (index, table) {
      console.log(table);
      var row = $("<tr>");
      var positionCell = $("<td>").text(table.position);
      var nameCell = $("<td>").text(table.team.name);
      var pointsCell = $("<td>").text(table.points);
      var formCell = $("<td>").text(table.form);

      row.append(positionCell, nameCell, pointsCell, formCell);
      tableBody.append(row);
    });
  }
}

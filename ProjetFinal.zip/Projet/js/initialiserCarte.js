/*
 * Contrôleur de la vue "stades.html".
 * @author França Nathan
 * @version 2.0 / 02.10.2023
 *
 */
function initialiserCarte() {
  const RedMarkerIcon = L.icon({
    iconUrl: "../images/redmarkericon.png",
    iconSize: [18, 30],
    iconAnchor: [9, 30],
    popupAnchor: [0, -20],
  });
  const GreenMarkerIcon = L.icon({
    iconUrl: "../images/greenmarkericon.png",
    iconSize: [18, 30],
    iconAnchor: [9, 30],
    popupAnchor: [0, -20],
  });
  const mapid = L.map("mapid").setView([53.4183726,-2.6701437], 9);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(mapid);

  L.marker([53.43089080173724, -2.9608757752981525], { icon: RedMarkerIcon })
    .addTo(mapid)
    .bindPopup("Voici le stade de Anfield, du club Liverpool");
  L.marker([53.4643424909605, -2.2917587888524773], { icon: GreenMarkerIcon })
    .addTo(mapid)
    .bindPopup("Voici le stade Old Trafford, du club Manchester United");
}
